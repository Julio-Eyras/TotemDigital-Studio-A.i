/**
 * Auth Service - Smart Signage v2.0
 * Serviço de autenticação unificado
 */

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { getDatabase } from '../config/database';
import { AuditService } from './auditService';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email?: string;
  role?: string;
  clientId?: number;
}

export interface AuthResponse {
  success: boolean;
  token?: string;
  refreshToken?: string;
  user?: {
    id: number;
    username: string;
    role: string;
    clientId?: number;
  };
  error?: string;
}

export interface ChangePasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export class AuthService {
  private get db() {
    return getDatabase();
  }
  
  // Lazy initialization - só criar quando necessário
  private getAuditService(): AuditService {
    if (!(global as any).auditServiceInstance) {
      (global as any).auditServiceInstance = new AuditService();
    }
    return (global as any).auditServiceInstance;
  }

  /**
   * Autentica usuário
   */
  async login(credentials: LoginRequest): Promise<AuthResponse> {
    try {
      const { username, password } = credentials;
      
      console.log(`[AUTH] Tentativa de login para usuário: ${username}`);
      console.log(`[AUTH] Senha fornecida (tamanho): ${password ? password.length : 0} caracteres`);

      // Buscar usuário
      console.log(`[AUTH] Buscando usuário no banco de dados...`);
      
      // Verificar se tabela clients existe antes de fazer JOIN
      const clientsTableExists = await this.db.tableExists('clients');
      let user;
      
      if (clientsTableExists) {
        // Tentar com JOIN se a tabela existir
        try {
          user = await this.db.findFirst(`
            SELECT u.*, c.name as client_name 
            FROM users u 
            LEFT JOIN clients c ON u.client_id = c.client_id 
            WHERE u.username = ? AND u.is_active = true
          `, [username]);
        } catch (error: any) {
          // Se falhar mesmo com a tabela existindo, tentar sem JOIN
          console.log(`[AUTH] ⚠️ Erro no JOIN com clients - buscando sem JOIN: ${error.message}`);
          user = await this.db.findFirst(`
            SELECT u.*
            FROM users u 
            WHERE u.username = ? AND u.is_active = true
          `, [username]);
        }
      } else {
        // Buscar sem JOIN se a tabela não existir
        console.log(`[AUTH] ⚠️ Tabela clients não existe - buscando usuário sem JOIN...`);
        user = await this.db.findFirst(`
          SELECT u.*
          FROM users u 
          WHERE u.username = ? AND u.is_active = true
        `, [username]);
      }

      console.log(`[AUTH] Resultado da busca: ${user ? `Usuário encontrado (ID: ${user.id})` : 'Usuário NÃO encontrado'}`);

      if (!user) {
        console.log(`[AUTH] ❌ Usuário '${username}' não encontrado ou inativo`);
        await this.getAuditService().log('auth', 'login_failed', null, { username, reason: 'user_not_found' }).catch(e => console.error('[AUTH] Erro ao registrar log:', e.message));
        return { success: false, error: 'Credenciais inválidas' };
      }

      console.log(`[AUTH] Usuário encontrado: ${user.username}, Role: ${user.role}, Email: ${user.email || 'N/A'}`);
      console.log(`[AUTH] Password hash do banco: ${user.password_hash ? `${user.password_hash.substring(0, 10)}...` : 'NÃO DEFINIDO'}`);

      // Verificar senha
      console.log(`[AUTH] Verificando senha...`);
      const isValidPassword = await bcrypt.compare(password, user.password_hash);
      console.log(`[AUTH] Senha válida: ${isValidPassword ? 'SIM' : 'NÃO'}`);

      if (!isValidPassword) {
        console.log(`[AUTH] ❌ Senha inválida para usuário '${username}'`);
        await this.getAuditService().log('auth', 'login_failed', user.id, { username, reason: 'invalid_password' }).catch(e => console.error('[AUTH] Erro ao registrar log:', e.message));
        return { success: false, error: 'Credenciais inválidas' };
      }

      // Atualizar último login
      console.log(`[AUTH] Atualizando último login...`);
      await this.db.executeRaw(`
        UPDATE users 
        SET last_login = CURRENT_TIMESTAMP 
        WHERE id = ?
      `, [user.id]).catch(e => console.error('[AUTH] Erro ao atualizar last_login:', e.message));

      // Gerar tokens
      console.log(`[AUTH] Gerando tokens JWT...`);
      const token = this.generateToken(user);
      const refreshToken = this.generateRefreshToken(user);
      console.log(`[AUTH] Tokens gerados com sucesso`);

      // Log de sucesso
      await this.getAuditService().log('auth', 'login_success', user.id, { username }).catch(e => console.error('[AUTH] Erro ao registrar log de sucesso:', e.message));

      console.log(`[AUTH] ✅ Login bem-sucedido para '${username}'`);

      return {
        success: true,
        token,
        refreshToken,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          clientId: user.client_id
        }
      };

    } catch (error: any) {
      console.error('❌ [AUTH] Erro no login:', error.message);
      console.error('❌ [AUTH] Stack trace:', error.stack);
      console.error('❌ [AUTH] Erro completo:', JSON.stringify(error, null, 2));
      
      // Verificar se é erro de banco de dados
      if (error.message && error.message.includes('relation') && error.message.includes('does not exist')) {
        console.error('❌ [AUTH] ERRO CRÍTICO: Tabela users não existe no banco de dados!');
        return { success: false, error: 'Erro interno: Tabela de usuários não encontrada. Verifique a instalação do banco de dados.' };
      }
      
      if (error.message && error.message.includes('column') && error.message.includes('does not exist')) {
        console.error(`❌ [AUTH] ERRO CRÍTICO: Coluna não existe na tabela users! Erro: ${error.message}`);
        return { success: false, error: 'Erro interno: Estrutura do banco de dados incorreta. Execute o schema-postgresql.sql para criar as tabelas.' };
      }
      
      return { success: false, error: `Erro interno do servidor: ${error.message}` };
    }
  }

  /**
   * Registra novo usuário
   */
  async register(data: RegisterRequest): Promise<AuthResponse> {
    try {
      const { username, password, email, role = 'client', clientId } = data;

      // Verificar se usuário já existe
      const existingUser = await this.db.findFirst(`
        SELECT id FROM users WHERE username = ?
      `, [username]);

      if (existingUser) {
        return { success: false, error: 'Nome de usuário já existe' };
      }

      // Hash da senha
      const saltRounds = 12;
      const passwordHash = await bcrypt.hash(password, saltRounds);

      // Criar usuário
      const result = await this.db.executeRaw(`
        INSERT INTO users (username, password_hash, role, client_id, is_active)
        VALUES (?, ?, ?, ?, 1)
      `, [username, passwordHash, role, clientId]);

      if (!result.lastInsertRowid) {
        return { success: false, error: 'Erro ao criar usuário' };
      }

      // Buscar usuário criado (com ou sem JOIN dependendo da existência da tabela)
      const clientsTableExists = await this.db.tableExists('clients');
      let newUser;
      if (clientsTableExists) {
        try {
          newUser = await this.db.findFirst(`
            SELECT u.*, c.name as client_name 
            FROM users u 
            LEFT JOIN clients c ON u.client_id = c.client_id 
            WHERE u.id = ?
          `, [result.lastInsertRowid]);
        } catch {
          newUser = await this.db.findFirst(`
            SELECT u.*
            FROM users u 
            WHERE u.id = ?
          `, [result.lastInsertRowid]);
        }
      } else {
        newUser = await this.db.findFirst(`
          SELECT u.*
          FROM users u 
          WHERE u.id = ?
        `, [result.lastInsertRowid]);
      }

      // Gerar tokens
      const token = this.generateToken(newUser);
      const refreshToken = this.generateRefreshToken(newUser);

      // Log de registro
      await this.getAuditService().log('auth', 'user_registered', newUser.id, { username, role });

      return {
        success: true,
        token,
        refreshToken,
        user: {
          id: newUser.id,
          username: newUser.username,
          role: newUser.role,
          clientId: newUser.client_id
        }
      };

    } catch (error: any) {
      console.error('❌ Erro no registro:', error.message);
      return { success: false, error: 'Erro interno do servidor' };
    }
  }

  /**
   * Atualiza token de acesso
   */
  async refreshToken(refreshToken: string): Promise<AuthResponse> {
    try {
      const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET!) as any;
      
      // Buscar usuário (com ou sem JOIN dependendo da existência da tabela)
      const clientsTableExists = await this.db.tableExists('clients');
      let user;
      if (clientsTableExists) {
        try {
          user = await this.db.findFirst(`
            SELECT u.*, c.name as client_name 
            FROM users u 
            LEFT JOIN clients c ON u.client_id = c.client_id 
            WHERE u.id = ? AND u.is_active = true
          `, [decoded.userId]);
        } catch {
          user = await this.db.findFirst(`
            SELECT u.*
            FROM users u 
            WHERE u.id = ? AND u.is_active = true
          `, [decoded.userId]);
        }
      } else {
        user = await this.db.findFirst(`
          SELECT u.*
          FROM users u 
          WHERE u.id = ? AND u.is_active = true
        `, [decoded.userId]);
      }

      if (!user) {
        return { success: false, error: 'Token inválido' };
      }

      // Gerar novo token
      const newToken = this.generateToken(user);

      return {
        success: true,
        token: newToken,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          clientId: user.client_id
        }
      };

    } catch (error: any) {
      console.error('❌ Erro no refresh token:', error.message);
      return { success: false, error: 'Token inválido' };
    }
  }

  /**
   * Altera senha do usuário
   */
  async changePassword(userId: number, data: ChangePasswordRequest): Promise<AuthResponse> {
    try {
      const { currentPassword, newPassword } = data;

      // Buscar usuário
      const user = await this.db.findFirst(`
        SELECT password_hash FROM users WHERE id = ? AND is_active = true
      `, [userId]);

      if (!user) {
        return { success: false, error: 'Usuário não encontrado' };
      }

      // Verificar senha atual
      const isValidPassword = await bcrypt.compare(currentPassword, user.password_hash);
      if (!isValidPassword) {
        await this.getAuditService().log('auth', 'password_change_failed', userId, { reason: 'invalid_current_password' });
        return { success: false, error: 'Senha atual incorreta' };
      }

      // Hash da nova senha
      const saltRounds = 12;
      const newPasswordHash = await bcrypt.hash(newPassword, saltRounds);

      // Atualizar senha
      await this.db.executeRaw(`
        UPDATE users 
        SET password_hash = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `, [newPasswordHash, userId]);

      // Log de alteração
      await this.getAuditService().log('auth', 'password_changed', userId, {});

      return { success: true };

    } catch (error: any) {
      console.error('❌ Erro ao alterar senha:', error.message);
      return { success: false, error: 'Erro interno do servidor' };
    }
  }

  /**
   * Busca dados do usuário autenticado
   */
  async getMe(userId: number): Promise<any> {
    try {
      // Buscar usuário (com ou sem JOIN dependendo da existência da tabela)
      const clientsTableExists = await this.db.tableExists('clients');
      let user;
      if (clientsTableExists) {
        try {
          user = await this.db.findFirst(`
            SELECT 
              u.id as user_id,
              u.username,
              u.role,
              u.is_active,
              u.last_login,
              u.created_at,
              u.updated_at,
              c.name as client_name,
              c.email as client_email
            FROM users u 
            LEFT JOIN clients c ON u.client_id = c.client_id 
            WHERE u.id = ? AND u.is_active = true
          `, [userId]);
        } catch {
          user = await this.db.findFirst(`
            SELECT 
              u.id as user_id,
              u.username,
              u.role,
              u.is_active,
              u.last_login,
              u.created_at,
              u.updated_at
            FROM users u 
            WHERE u.id = ? AND u.is_active = true
          `, [userId]);
        }
      } else {
        user = await this.db.findFirst(`
          SELECT 
            u.id as user_id,
            u.username,
            u.role,
            u.is_active,
            u.last_login,
            u.created_at,
            u.updated_at
          FROM users u 
          WHERE u.id = ? AND u.is_active = true
        `, [userId]);
      }

      if (!user) {
        return null;
      }

      // Buscar permissões do usuário
      const permissions = await this.db.findMany(`
        SELECT p.name, p.resource, p.action
        FROM user_roles ur
        JOIN role_permissions rp ON ur.role_id = rp.role_id
        JOIN permissions p ON rp.permission_id = p.permission_id
        WHERE ur.user_id = ?
      `, [userId]);

      return {
        ...user,
        permissions: permissions.map(p => p.name)
      };

    } catch (error: any) {
      console.error('❌ Erro ao buscar dados do usuário:', error.message);
      return null;
    }
  }

  /**
   * Logout (invalida token)
   */
  async logout(userId: number): Promise<AuthResponse> {
    try {
      // Log de logout
      await this.getAuditService().log('auth', 'logout', userId, {});

      return { success: true };

    } catch (error: any) {
      console.error('❌ Erro no logout:', error.message);
      return { success: false, error: 'Erro interno do servidor' };
    }
  }

  /**
   * Gera token JWT
   */
  private generateToken(user: any): string {
    const payload = {
      userId: user.id,
      username: user.username,
      role: user.role,
      clientId: user.client_id
    };

    return jwt.sign(payload, process.env.JWT_SECRET!, {
      expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    } as jwt.SignOptions);
  }

  /**
   * Gera refresh token
   */
  private generateRefreshToken(user: any): string {
    const payload = {
      userId: user.id,
      type: 'refresh'
    };

    return jwt.sign(payload, process.env.JWT_SECRET!, {
      expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
    } as jwt.SignOptions);
  }

  /**
   * Verifica se PIN de abandono está correto
   */
  async verifyAbandonPin(pin: string): Promise<boolean> {
    const correctPin = process.env.PLAYER_ABANDON_PIN || '1234';
    return pin === correctPin;
  }

  /**
   * Solicita recuperação de senha (forgot password)
   */
  async forgotPassword(email: string): Promise<{ success: boolean; message: string; token?: string }> {
    try {
      // Buscar usuário por email
      const user = await this.db.findFirst(`
        SELECT id, username, email, is_active
        FROM users
        WHERE email = ? AND is_active = true
      `, [email]);

      // Por segurança, sempre retornar sucesso mesmo se email não existir
      // Isso previne enumeração de emails
      if (!user) {
        console.log(`[PASSWORD_RESET] Tentativa de recuperação para email não cadastrado: ${email}`);
        return {
          success: true,
          message: 'Se o email estiver cadastrado, você receberá um link de recuperação.'
        };
      }

      // Invalidar tokens anteriores do usuário
      await this.db.executeRaw(`
        UPDATE password_reset_tokens
        SET used = true
        WHERE user_id = ? AND used = false
      `, [user.id]);

      // Gerar token seguro
      const token = this.generatePasswordResetToken();
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 1); // Token expira em 1 hora

      // Salvar token no banco
      await this.db.executeRaw(`
        INSERT INTO password_reset_tokens (user_id, token, expires_at)
        VALUES (?, ?, ?)
      `, [user.id, token, expiresAt]);

      // Log de auditoria
      await this.getAuditService().log('auth', 'password_reset_requested', user.id, {
        email: email,
        username: user.username
      });

      // Enviar email de recuperação de senha
      try {
        const { emailService } = await import('./emailService');
        const emailResult = await emailService.sendPasswordResetEmail(
          user.email || email,
          token,
          user.username
        );

        if (!emailResult.success && process.env.NODE_ENV === 'development') {
          console.log(`\n🔐 [PASSWORD RESET] Token gerado para ${email}:`);
          console.log(`   Token: ${token}`);
          console.log(`   Expira em: ${expiresAt.toISOString()}`);
          console.log(`   Link: ${process.env.FRONTEND_URL || 'http://localhost:3001'}/reset-password?token=${token}\n`);
        }
      } catch (emailError: any) {
        console.error('❌ Erro ao enviar email de recuperação de senha:', emailError.message);
        // Em desenvolvimento, mostrar token no console
        if (process.env.NODE_ENV === 'development') {
          console.log(`\n🔐 [PASSWORD RESET] Token gerado para ${email}:`);
          console.log(`   Token: ${token}`);
          console.log(`   Expira em: ${expiresAt.toISOString()}`);
          console.log(`   Link: ${process.env.FRONTEND_URL || 'http://localhost:3001'}/reset-password?token=${token}\n`);
        }
      }

      return {
        success: true,
        message: 'Se o email estiver cadastrado, você receberá um link de recuperação.',
        token: process.env.NODE_ENV === 'development' ? token : undefined // Apenas em dev
      };

    } catch (error: any) {
      console.error('❌ Erro ao solicitar recuperação de senha:', error.message);
      return {
        success: false,
        message: 'Erro ao processar solicitação de recuperação de senha'
      };
    }
  }

  /**
   * Redefine senha usando token (reset password)
   */
  async resetPassword(token: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    try {
      // Buscar token válido
      const resetToken = await this.db.findFirst(`
        SELECT prt.*, u.id as user_id, u.username, u.email
        FROM password_reset_tokens prt
        INNER JOIN users u ON prt.user_id = u.id
        WHERE prt.token = ? 
          AND prt.used = false 
          AND prt.expires_at > CURRENT_TIMESTAMP
          AND u.is_active = true
      `, [token]);

      if (!resetToken) {
        return {
          success: false,
          message: 'Token inválido ou expirado. Solicite uma nova recuperação de senha.'
        };
      }

      // Validar nova senha
      if (!newPassword || newPassword.length < 6) {
        return {
          success: false,
          message: 'A nova senha deve ter pelo menos 6 caracteres'
        };
      }

      // Hash da nova senha
      const saltRounds = 12;
      const passwordHash = await bcrypt.hash(newPassword, saltRounds);

      // Atualizar senha do usuário
      await this.db.executeRaw(`
        UPDATE users
        SET password_hash = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [passwordHash, resetToken.user_id]);

      // Marcar token como usado
      await this.db.executeRaw(`
        UPDATE password_reset_tokens
        SET used = true
        WHERE id = ?
      `, [resetToken.id]);

      // Log de auditoria
      await this.getAuditService().log('auth', 'password_reset_completed', resetToken.user_id, {
        username: resetToken.username,
        email: resetToken.email
      });

      return {
        success: true,
        message: 'Senha redefinida com sucesso. Você já pode fazer login com a nova senha.'
      };

    } catch (error: any) {
      console.error('❌ Erro ao redefinir senha:', error.message);
      return {
        success: false,
        message: 'Erro ao processar redefinição de senha'
      };
    }
  }

  /**
   * Gera token seguro para recuperação de senha
   */
  private generatePasswordResetToken(): string {
    // Gerar token aleatório de 32 bytes (256 bits) em hexadecimal
    return crypto.randomBytes(32).toString('hex');
  }

  /**
   * Limpa tokens expirados (manutenção)
   */
  async cleanupExpiredTokens(): Promise<number> {
    try {
      const result = await this.db.executeRaw(`
        DELETE FROM password_reset_tokens
        WHERE expires_at < CURRENT_TIMESTAMP OR used = true
      `);

      return (result as any).rowCount || 0;
    } catch (error: any) {
      console.error('❌ Erro ao limpar tokens expirados:', error.message);
      return 0;
    }
  }

  /**
   * Cria usuário admin padrão se não existir
   */
  async createDefaultAdmin(): Promise<void> {
    try {
      const adminExists = await this.db.findFirst(`
        SELECT id FROM users WHERE username = 'admin'
      `);

      if (adminExists) {
        console.log('✅ Usuário admin já existe');
        return;
      }

      const saltRounds = 12;
      const passwordHash = await bcrypt.hash('admin', saltRounds);

      await this.db.executeRaw(`
        INSERT INTO users (username, password_hash, role, is_active)
        VALUES ('admin', ?, 'admin', 1)
      `, [passwordHash]);

      console.log('✅ Usuário admin padrão criado (admin/admin)');

    } catch (error: any) {
      console.error('❌ Erro ao criar admin padrão:', error.message);
    }
  }
}

