#!/bin/bash

# Script para corrigir tabelas do banco de dados
# Execute este script se as tabelas não foram criadas corretamente

INSTALL_DIR="/home/smartchannel/smartsignage-pro-main"
DATABASE_URL="postgresql://smartsignage:smartsignage123@localhost:5432/smartsignage"

echo "🔧 Corrigindo schema do banco de dados..."

cd "$INSTALL_DIR" || exit 1

# Verificar se o arquivo schema-postgresql.sql existe
SCHEMA_SQL_FILE="$INSTALL_DIR/database/schema-postgresql.sql"
if [[ ! -f "$SCHEMA_SQL_FILE" ]]; then
    echo "❌ Arquivo schema-postgresql.sql não encontrado!"
    exit 1
fi

echo "✅ Executando schema-postgresql.sql..."

# Executar schema SQL ignorando erros de "already exists"
psql "$DATABASE_URL" -f "$SCHEMA_SQL_FILE" 2>&1 | grep -v "already exists" | grep -v "NOTICE" || true

# Verificar quantas tabelas foram criadas
TABLE_COUNT=$(psql "$DATABASE_URL" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE';" 2>/dev/null | tr -d ' ')

echo "✅ Tabelas encontradas no banco: $TABLE_COUNT"

if [[ -n "$TABLE_COUNT" ]] && [[ "$TABLE_COUNT" -gt 30 ]]; then
    echo "✅ Schema criado com sucesso! ($TABLE_COUNT tabelas)"
    
    # Listar tabelas criadas
    echo ""
    echo "📋 Tabelas criadas:"
    psql "$DATABASE_URL" -t -c "SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name;" 2>/dev/null
    
    # Executar seed data
    echo ""
    echo "🌱 Executando seed data..."
    INIT_DATA_FILE="$INSTALL_DIR/database/init-data.sql"
    if [[ -f "$INIT_DATA_FILE" ]]; then
        psql "$DATABASE_URL" -f "$INIT_DATA_FILE" 2>&1 | grep -v "already exists" | grep -v "NOTICE" || true
        echo "✅ Seed data executado"
    else
        echo "⚠️ Arquivo init-data.sql não encontrado"
    fi
else
    echo "⚠️ Poucas tabelas criadas ($TABLE_COUNT). Verifique o schema SQL."
fi

echo ""
echo "✅ Correção concluída!"

