#!/bin/bash

# =============================================================================
# Script para corrigir permissões e line endings de scripts .sh
# =============================================================================
# Uso: ./FIX-SCRIPT-PERMISSIONS.sh
# =============================================================================

echo "Corrigindo permissoes e line endings dos scripts..."

# Encontrar todos os scripts .sh e corrigir
find . -name "*.sh" -type f | while read script; do
    echo "Corrigindo: $script"
    
    # Converter line endings para LF (se ainda nao estiver)
    dos2unix "$script" 2>/dev/null || sed -i 's/\r$//' "$script"
    
    # Dar permissao de execucao
    chmod +x "$script"
    
    echo "  [OK] $script corrigido"
done

echo ""
echo "Todos os scripts foram corrigidos!"
echo ""
echo "Agora voce pode executar:"
echo "  ./install-smartsignage.sh"

