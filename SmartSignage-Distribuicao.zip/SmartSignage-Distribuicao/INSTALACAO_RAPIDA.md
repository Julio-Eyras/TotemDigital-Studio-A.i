# 🚀 Instalação Rápida - SmartSignage Pro

## Instalação em 3 Passos

### 1️⃣ Preparar o Sistema

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependências básicas
sudo apt install -y curl wget git
```

### 2️⃣ Executar Instalação

```bash
# Dar permissão
chmod +x install-smartsignage.sh

# Executar (modo Docker recomendado)
sudo ./install-smartsignage.sh
```

Durante a instalação, escolha:
- **Modo de instalação**: `docker` (recomendado)
- **Configuração HTTPS**: Opcional (pode configurar depois)

### 3️⃣ Acessar o Sistema

Após instalação concluída:

1. Acesse: **http://seu-ip-ou-dominio/**
2. Login: `admin` / Senha: `admin123`
3. ⚠️ **ALTERE A SENHA IMEDIATAMENTE**

---

## ✅ Verificação Rápida

```bash
# Verificar containers
docker-compose ps

# Verificar serviços
curl http://localhost:3000/health
curl http://localhost/api/health
```

---

## 🔧 Comandos Úteis

```bash
# Iniciar
docker-compose up -d

# Parar
docker-compose down

# Reiniciar
docker-compose restart

# Ver logs
docker-compose logs -f

# Status
docker-compose ps
```

---

## 📞 Problemas?

Consulte `README.md` para solução de problemas detalhada.

