# 📦 Estrutura do Pacote de Distribuição

## Arquivos Principais

### Instalação
- `install-smartsignage.sh` - Script principal de instalação automática
- `INSTALACAO_RAPIDA.md` - Guia de instalação rápida
- `README.md` - Documentação completa

### Docker
- `docker-compose.yml` - Orquestração de todos os serviços
- `Dockerfile.app` - Imagem da aplicação monolito
- `Dockerfile.backend` - Imagem do backend
- `Dockerfile.frontend` - Imagem do frontend

### Configuração
- `env.example` - Exemplo de variáveis de ambiente
- `.gitignore` - Arquivos ignorados pelo Git

### Informações
- `VERSION.txt` - Versão e informações do pacote
- `CHANGELOG.md` - Histórico de mudanças

---

## Diretórios

### `database/`
Scripts e esquemas do banco de dados PostgreSQL:
- `smartchannel-db.sql` - Schema principal
- `init-data.sql` - Dados iniciais
- `scripts/` - Scripts auxiliares (apply, validate)

### `docker/`
Configurações e entrypoints Docker:
- `entrypoint.sh` - Entrypoint principal
- `app-entrypoint.sh` - Entrypoint da aplicação
- `nginx-entrypoint.sh` - Entrypoint do Nginx
- `mosquitto/` - Configuração MQTT Broker
  - `mosquitto.conf`

### `nginx/`
Configurações do Nginx (reverse proxy):
- `nginx.conf` - Configuração principal
- `frontend.conf` - Configuração do frontend
- `nginx-reverse-proxy.conf` - Proxy reverso
- Outras configurações auxiliares

### `monitoring/`
Configurações de monitoramento:
- `prometheus/` - Configuração Prometheus
- `grafana/` - Configuração Grafana
  - `dashboards/` - Dashboards pré-configurados
  - `datasources/` - Fontes de dados
  - `alerts/` - Alertas

### `scripts/`
Scripts auxiliares:
- `post-install-check.sh` - Verificação pós-instalação
- `health-check.sh` - Verificação de saúde dos serviços

### `docs/`
Documentação adicional:
- `README_INSTALACAO_SERVIDOR.md` - Guia detalhado de instalação

---

## Checklist de Conteúdo

✅ Script de instalação principal  
✅ Docker Compose e Dockerfiles  
✅ Configurações de banco de dados  
✅ Configurações Docker (entrypoints)  
✅ Configurações Nginx  
✅ Configurações MQTT  
✅ Configurações de monitoramento  
✅ Scripts auxiliares  
✅ Documentação completa  
✅ Arquivo de versão  

---

## Tamanho Aproximado

- **Arquivos**: ~37 arquivos
- **Tamanho Total**: ~2-5 MB (sem node_modules)
- **Espaço Necessário para Instalação**: ~10 GB (com Docker images)

---

## Requisitos Mínimos

- Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+)
- Docker 20.10+
- Docker Compose 2.0+
- 4GB RAM (8GB recomendado)
- 10GB espaço em disco

---

**Última Atualização**: 2025-01-XX

