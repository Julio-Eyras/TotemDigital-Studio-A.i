# SmartSignage Pro - Pacote de Distribuição

**Versão**: 3.1  
**Data**: 2025-01-XX

---

## 📦 Conteúdo do Pacote

Este pacote contém **TODOS** os arquivos necessários para instalar, executar e colocar o sistema SmartSignage Pro em operação, incluindo:

✅ **Código fonte completo do Backend** (184 arquivos TypeScript)  
✅ **Código fonte completo do Frontend** (62 arquivos TypeScript/TSX)  
✅ **Scripts de instalação e configuração**  
✅ **Configurações Docker e banco de dados**  
✅ **Configurações MQTT para SmartDisplayFX**  
✅ **Monitoramento (Prometheus + Grafana)**  

**Total: 297 arquivos** - Sistema completo e funcional!

### Estrutura de Diretórios

```
SmartSignage-Distribuicao/
├── install-smartsignage.sh      # Script principal de instalação
├── docker-compose.yml            # Configuração Docker Compose
├── Dockerfile.app                # Dockerfile da aplicação monolito
├── Dockerfile.backend            # Dockerfile do backend
├── Dockerfile.frontend           # Dockerfile do frontend
├── env.example                   # Exemplo de variáveis de ambiente
├── README.md                     # Este arquivo
│
├── backend/                      # ⭐ CÓDIGO FONTE DO BACKEND
│   ├── package.json             # Dependências do backend
│   ├── tsconfig.json            # Configuração TypeScript
│   └── src/                     # Código fonte completo
│       ├── index.ts             # Entrada principal
│       ├── routes/              # Rotas da API
│       ├── services/            # Serviços de negócio
│       ├── middleware/          # Middlewares
│       └── ...                  # (184 arquivos TypeScript)
│
├── frontend/                     # ⭐ CÓDIGO FONTE DO FRONTEND
│   ├── package.json             # Dependências do frontend
│   ├── tsconfig.json            # Configuração TypeScript
│   ├── public/                  # Arquivos públicos
│   │   ├── index.html
│   │   └── manifest.json
│   └── src/                     # Código fonte completo
│       ├── App.tsx              # Componente principal
│       ├── components/          # Componentes React
│       ├── pages/               # Páginas da aplicação
│       ├── services/            # Serviços de API
│       └── ...                  # (62 arquivos TypeScript/TSX)
│
├── database/                     # Scripts de banco de dados
│   ├── smartchannel-db.sql      # Schema principal do banco
│   ├── init-data.sql            # Dados iniciais
│   └── scripts/                 # Scripts auxiliares de banco
│
├── docker/                       # Configurações Docker
│   ├── entrypoint.sh            # Entrypoint principal
│   ├── app-entrypoint.sh        # Entrypoint da aplicação
│   ├── nginx-entrypoint.sh      # Entrypoint do Nginx
│   └── mosquitto/               # Configuração MQTT
│       └── mosquitto.conf
│
├── nginx/                        # Configurações Nginx
│   ├── nginx.conf               # Configuração principal
│   ├── frontend.conf            # Configuração do frontend
│   └── ...
│
├── monitoring/                   # Configurações de monitoramento
│   ├── prometheus/              # Configuração Prometheus
│   └── grafana/                 # Configuração Grafana
│
├── scripts/                      # Scripts auxiliares
│   ├── post-install-check.sh    # Verificação pós-instalação
│   └── health-check.sh          # Verificação de saúde
│
└── docs/                         # Documentação adicional
```

---

## 🚀 Instalação Rápida

### Pré-requisitos

- **Sistema Operacional**: Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+)
- **Docker**: 20.10+ e Docker Compose 2.0+
- **Espaço em Disco**: Mínimo 10GB livres
- **RAM**: Mínimo 4GB (recomendado 8GB+)
- **Portas Livres**: 80, 443, 3000, 5432, 6379, 1883, 9001, 9090, 3002, 11434

### Instalação Automática

```bash
# 1. Dar permissão de execução ao script
chmod +x install-smartsignage.sh

# 2. Executar instalação
sudo ./install-smartsignage.sh
```

O script irá:
- ✅ Verificar pré-requisitos
- ✅ Instalar dependências necessárias
- ✅ Configurar Docker e Docker Compose
- ✅ Criar e configurar banco de dados
- ✅ Configurar variáveis de ambiente
- ✅ Construir e iniciar containers
- ✅ Verificar todos os serviços
- ✅ Configurar MQTT Broker para SmartDisplayFX

### Instalação Manual (Docker)

```bash
# 1. Configurar variáveis de ambiente
cp env.example .env
nano .env  # Editar conforme necessário

# 2. Iniciar serviços
docker-compose up -d

# 3. Verificar status
docker-compose ps
```

---

## ⚙️ Configuração

### Variáveis de Ambiente

Edite o arquivo `.env` (copiado de `env.example`) e configure:

```bash
# Banco de Dados
DATABASE_URL=postgresql://smartsignage:smartsignage123@localhost:5432/smartsignage

# JWT Secret (IMPORTANTE: Altere em produção!)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# SmartDisplayFX / MQTT
SMARTDISPLAYFX_MQTT_ENABLED=true
SMARTDISPLAYFX_MQTT_URL=mqtt://localhost:1883
SMARTDISPLAYFX_MQTT_WS_URL=ws://localhost:9001
SMARTDISPLAYFX_MQTT_PREFIX=smartdisplay
```

### Portas dos Serviços

| Serviço | Porta | Descrição |
|---------|-------|-----------|
| Frontend | 80, 443 | Interface web |
| Backend API | 3000 | API REST |
| PostgreSQL | 5432 | Banco de dados |
| Redis | 6379 | Cache |
| MQTT (TCP) | 1883 | Broker MQTT |
| MQTT (WebSocket) | 9001 | MQTT WebSocket |
| Prometheus | 9090 | Métricas |
| Grafana | 3002 | Dashboards |
| Ollama | 11434 | IA |

---

## 🔧 Operação

### Iniciar Sistema

```bash
docker-compose up -d
```

### Parar Sistema

```bash
docker-compose down
```

### Reiniciar Sistema

```bash
docker-compose restart
```

### Ver Logs

```bash
# Todos os serviços
docker-compose logs -f

# Serviço específico
docker-compose logs -f app
docker-compose logs -f postgres
docker-compose logs -f mqtt
```

### Verificar Status

```bash
# Status dos containers
docker-compose ps

# Verificar saúde dos serviços
./scripts/health-check.sh
```

---

## 📊 Acesso ao Sistema

Após a instalação, acesse:

- **Frontend Admin**: http://seu-servidor/
- **Backend API**: http://seu-servidor:3000/api
- **API Docs (Swagger)**: http://seu-servidor:3000/api/docs
- **Grafana**: http://seu-servidor:3002 (admin/admin)
- **Prometheus**: http://seu-servidor:9090

### Credenciais Padrão

- **Usuário Admin**: `admin`
- **Senha Admin**: `admin123` ⚠️ **ALTERE IMEDIATAMENTE APÓS PRIMEIRO LOGIN**

---

## 🔍 Verificação Pós-Instalação

Execute o script de verificação:

```bash
./scripts/post-install-check.sh
```

Este script verifica:
- ✅ Status dos containers Docker
- ✅ Conectividade dos serviços
- ✅ Banco de dados
- ✅ MQTT Broker
- ✅ Endpoints da API
- ✅ Frontend

---

## 🐛 Solução de Problemas

### Containers não iniciam

```bash
# Ver logs de erro
docker-compose logs

# Verificar recursos do sistema
docker stats

# Reiniciar containers
docker-compose restart
```

### Banco de dados não conecta

```bash
# Verificar se PostgreSQL está rodando
docker-compose ps postgres

# Ver logs do PostgreSQL
docker-compose logs postgres

# Verificar conexão
docker-compose exec postgres psql -U smartsignage -d smartsignage
```

### MQTT não funciona

```bash
# Verificar container MQTT
docker-compose ps mqtt

# Ver logs MQTT
docker-compose logs mqtt

# Testar conexão MQTT
mosquitto_sub -h localhost -p 1883 -t '$SYS/#' -C 1
```

### Portas já em uso

Edite `docker-compose.yml` e altere as portas mapeadas:

```yaml
ports:
  - "${FRONTEND_PORT:-8080}:80"  # Mude 8080 para outra porta
```

---

## 📝 Backup e Restauração

### Backup do Banco de Dados

```bash
docker-compose exec postgres pg_dump -U smartsignage smartsignage > backup.sql
```

### Restauração do Banco de Dados

```bash
docker-compose exec -T postgres psql -U smartsignage smartsignage < backup.sql
```

### Backup Completo

```bash
# Backup de volumes Docker
docker run --rm -v smartsignage_postgres_data:/data -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz /data
```

---

## 🔐 Segurança

### Antes de Colocar em Produção

1. ✅ Alterar `JWT_SECRET` no `.env`
2. ✅ Alterar senha do admin no primeiro login
3. ✅ Configurar HTTPS (Let's Encrypt)
4. ✅ Configurar firewall
5. ✅ Configurar autenticação MQTT (se necessário)
6. ✅ Revisar permissões de arquivos
7. ✅ Configurar backups automáticos

---

## 📞 Suporte

Para mais informações, consulte:

- **Documentação Completa**: `docs/`
- **Logs do Sistema**: `docker-compose logs`
- **Status dos Serviços**: `docker-compose ps`

---

## 📄 Licença

[Informações de licença do projeto]

---

## 🎯 Próximos Passos

Após instalação bem-sucedida:

1. Acesse o frontend e faça login
2. Configure seu primeiro cliente
3. Adicione totens/players
4. Configure campanhas
5. Configure SmartDisplayFX (se necessário)

---

**Versão do Pacote**: 3.1  
**Data de Compilação**: 2025-01-XX  
**Compatibilidade**: Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+)

