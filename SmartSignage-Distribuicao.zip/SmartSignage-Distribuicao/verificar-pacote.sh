#!/bin/bash
# Script de Verificação do Pacote de Distribuição
# Verifica se todos os arquivos essenciais estão presentes

echo "🔍 Verificando pacote de distribuição SmartSignage Pro..."
echo ""

ERROS=0
AVISOS=0

# Função para verificar arquivo
verificar_arquivo() {
    if [ -f "$1" ]; then
        echo "✅ $1"
    else
        echo "❌ $1 - FALTANDO"
        ((ERROS++))
    fi
}

# Função para verificar diretório
verificar_diretorio() {
    if [ -d "$1" ]; then
        echo "✅ $1/"
        if [ "$2" != "" ] && [ -f "$1/$2" ]; then
            echo "   ✅ $1/$2"
        elif [ "$2" != "" ]; then
            echo "   ⚠️  $1/$2 - FALTANDO"
            ((AVISOS++))
        fi
    else
        echo "❌ $1/ - FALTANDO"
        ((ERROS++))
    fi
}

echo "📋 Verificando arquivos principais..."
verificar_arquivo "install-smartsignage.sh"
verificar_arquivo "docker-compose.yml"
verificar_arquivo "env.example"
verificar_arquivo "README.md"
verificar_arquivo "INSTALACAO_RAPIDA.md"
verificar_arquivo "VERSION.txt"
verificar_arquivo "CHANGELOG.md"
echo ""

echo "🐳 Verificando Dockerfiles..."
verificar_arquivo "Dockerfile.app"
verificar_arquivo "Dockerfile.backend"
verificar_arquivo "Dockerfile.frontend"
echo ""

echo "💾 Verificando banco de dados..."
verificar_diretorio "database"
verificar_arquivo "database/smartchannel-db.sql"
verificar_arquivo "database/init-data.sql"
verificar_diretorio "database/scripts"
verificar_arquivo "database/scripts/apply-schema.sh"
verificar_arquivo "database/scripts/validate-schema.sh"
echo ""

echo "🐳 Verificando configurações Docker..."
verificar_diretorio "docker"
verificar_arquivo "docker/entrypoint.sh"
verificar_arquivo "docker/app-entrypoint.sh"
verificar_arquivo "docker/nginx-entrypoint.sh"
verificar_diretorio "docker/mosquitto"
verificar_arquivo "docker/mosquitto/mosquitto.conf"
echo ""

echo "🌐 Verificando configurações Nginx..."
verificar_diretorio "nginx"
verificar_arquivo "nginx/nginx.conf"
verificar_arquivo "nginx/frontend.conf"
echo ""

echo "📊 Verificando monitoramento..."
verificar_diretorio "monitoring"
verificar_diretorio "monitoring/prometheus"
verificar_diretorio "monitoring/grafana"
echo ""

echo "📜 Verificando scripts auxiliares..."
verificar_diretorio "scripts"
verificar_arquivo "scripts/post-install-check.sh"
verificar_arquivo "scripts/health-check.sh"
echo ""

echo "📚 Verificando documentação..."
verificar_diretorio "docs"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Resumo da Verificação"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ $ERROS -eq 0 ] && [ $AVISOS -eq 0 ]; then
    echo "✅ Pacote completo e pronto para distribuição!"
    exit 0
elif [ $ERROS -eq 0 ]; then
    echo "⚠️  Pacote completo com $AVISOS aviso(s)"
    exit 0
else
    echo "❌ Pacote incompleto: $ERROS erro(s), $AVISOS aviso(s)"
    exit 1
fi

