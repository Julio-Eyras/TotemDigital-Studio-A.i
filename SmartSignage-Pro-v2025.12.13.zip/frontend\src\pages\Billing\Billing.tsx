/**
 * Billing Page - Smart Signage v2.1
 * Página completa de gerenciamento de planos, assinaturas e faturas
 */

import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Alert,
  Chip,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Payment,
  Add,
  Refresh,
  Check,
  Cancel,
  CreditCard,
  Receipt,
  CheckCircle,
  Cancel as CancelIcon,
  Schedule,
} from '@mui/icons-material';
import { billingApi, BillingItem, CreateBillingRequest } from '../../services/api';
import { planApi, Plan, subscriptionApi, Subscription } from '../../services/api';
import { useNotification } from '../../hooks/useNotification';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const Billing: React.FC = () => {
  const { showSuccess, showError } = useNotification();
  const [tabValue, setTabValue] = useState(0);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [items, setItems] = useState<BillingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [subscribeOpen, setSubscribeOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [newBill, setNewBill] = useState<CreateBillingRequest>({ billing_type: 'subscription', amount: 0 });

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      setLoading(true);
      await Promise.all([
        loadPlans(),
        loadSubscriptions(),
        loadBillings(),
      ]);
    } catch (e) {
      console.error('Erro ao carregar dados:', e);
      setError('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const loadPlans = async () => {
    try {
      const plansData = await planApi.getAll();
      setPlans(plansData);
    } catch (e) {
      console.error('Erro ao carregar planos:', e);
      showError('Erro ao carregar planos');
    }
  };

  const loadSubscriptions = async () => {
    try {
      const subsData = await subscriptionApi.getAll();
      setSubscriptions(subsData);
    } catch (e) {
      console.error('Erro ao carregar assinaturas:', e);
      showError('Erro ao carregar assinaturas');
    }
  };

  const loadBillings = async () => {
    try {
      const resp = await billingApi.getAll();
      const itemsArray = Array.isArray(resp) ? resp : [];
      const normalizedItems = itemsArray.map(item => ({
        ...item,
        amount: typeof item.amount === 'number' ? item.amount : parseFloat(String(item.amount || 0))
      }));
      setItems(normalizedItems);
    } catch (e) {
      console.error('Erro ao carregar faturas:', e);
      showError('Erro ao carregar faturas');
    }
  };

  const handleCreate = async () => {
    try {
      await billingApi.create(newBill);
      setCreateOpen(false);
      setNewBill({ billing_type: 'subscription', amount: 0 });
      loadBillings();
      showSuccess('Cobrança criada com sucesso');
    } catch (e: any) {
      setError(e.response?.data?.message || 'Erro ao criar cobrança');
      showError('Erro ao criar cobrança');
    }
  };

  const handleSubscribe = async () => {
    if (!selectedPlan) return;

    try {
      const checkout = await subscriptionApi.create({
        planId: selectedPlan.plan_id,
      });

      // Redirecionar para Stripe Checkout
      if (checkout.url) {
        window.location.href = checkout.url;
      } else {
        showError('Erro ao criar sessão de checkout');
      }
    } catch (e: any) {
      setError(e.response?.data?.message || 'Erro ao criar assinatura');
      showError('Erro ao criar assinatura');
    }
  };

  const handleCancelSubscription = async (id: number) => {
    if (!window.confirm('Tem certeza que deseja cancelar esta assinatura?')) return;

    try {
      await subscriptionApi.cancel(id);
      loadSubscriptions();
      showSuccess('Assinatura cancelada com sucesso');
    } catch (e: any) {
      showError(e.response?.data?.message || 'Erro ao cancelar assinatura');
    }
  };

  const markPaid = async (id: number) => {
    try {
      await billingApi.markAsPaid(id);
      loadBillings();
      showSuccess('Fatura marcada como paga');
    } catch (e: any) {
      showError('Erro ao marcar como pago');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'paid':
        return 'success';
      case 'cancelled':
      case 'unpaid':
        return 'error';
      case 'past_due':
        return 'warning';
      case 'trialing':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatCurrency = (amount: number, currency: string = 'BRL') => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(amount);
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, mb: 4 }}>
        Faturamento e Assinaturas
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={(_, newValue) => setTabValue(newValue)}>
          <Tab label="Planos" icon={<CreditCard />} iconPosition="start" />
          <Tab label="Assinaturas" icon={<Receipt />} iconPosition="start" />
          <Tab label="Faturas" icon={<Payment />} iconPosition="start" />
        </Tabs>
      </Box>

      {/* TAB: PLANOS */}
      <TabPanel value={tabValue} index={0}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
          <Typography variant="h6">Planos Disponíveis</Typography>
          <Button
            startIcon={<Refresh />}
            variant="outlined"
            onClick={loadPlans}
            disabled={loading}
          >
            Atualizar
          </Button>
        </Box>

        <Grid container spacing={3}>
          {plans.map((plan) => (
            <Grid item xs={12} md={4} key={plan.plan_id}>
              <Card
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  border: plan.is_active ? '2px solid' : '1px solid',
                  borderColor: plan.is_active ? 'primary.main' : 'divider',
                }}
              >
                <CardContent sx={{ flexGrow: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {plan.name}
                    </Typography>
                    <Chip
                      label={plan.is_active ? 'Ativo' : 'Inativo'}
                      color={plan.is_active ? 'success' : 'default'}
                      size="small"
                    />
                  </Box>

                  <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                    {formatCurrency(plan.price, plan.currency)}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    / {plan.billing_interval === 'month' ? 'mês' : 'ano'}
                  </Typography>

                  {plan.description && (
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {plan.description}
                    </Typography>
                  )}

                  <Typography variant="subtitle2" sx={{ mt: 2, mb: 1, fontWeight: 600 }}>
                    Recursos:
                  </Typography>
                  <Box component="ul" sx={{ m: 0, pl: 2 }}>
                    {plan.features.map((feature, idx) => (
                      <li key={idx}>
                        <Typography variant="body2">{feature}</Typography>
                      </li>
                    ))}
                  </Box>
                </CardContent>
                <CardActions>
                  <Button
                    fullWidth
                    variant="contained"
                    startIcon={<Add />}
                    onClick={() => {
                      setSelectedPlan(plan);
                      setSubscribeOpen(true);
                    }}
                    disabled={!plan.is_active}
                  >
                    Assinar
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </TabPanel>

      {/* TAB: ASSINATURAS */}
      <TabPanel value={tabValue} index={1}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
          <Typography variant="h6">Minhas Assinaturas</Typography>
          <Button
            startIcon={<Refresh />}
            variant="outlined"
            onClick={loadSubscriptions}
            disabled={loading}
          >
            Atualizar
          </Button>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Plano</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Valor</TableCell>
                <TableCell>Período</TableCell>
                <TableCell>Início</TableCell>
                <TableCell>Próximo Pagamento</TableCell>
                <TableCell align="right">Ações</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {subscriptions.map((sub) => (
                <TableRow key={sub.subscription_id}>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {sub.plan?.name || `Plano #${sub.plan_id}`}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={sub.status}
                      color={getStatusColor(sub.status) as any}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>
                    {formatCurrency(sub.amount, sub.currency)}
                  </TableCell>
                  <TableCell>
                    {sub.billing_interval === 'month' ? 'Mensal' : 'Anual'}
                  </TableCell>
                  <TableCell>
                    {new Date(sub.start_date).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell>
                    {new Date(sub.current_period_end).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell align="right">
                    {sub.status === 'active' && (
                      <Tooltip title="Cancelar Assinatura">
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => handleCancelSubscription(sub.subscription_id)}
                        >
                          <CancelIcon />
                        </IconButton>
                      </Tooltip>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {subscriptions.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    <Typography variant="body2" color="text.secondary">
                      Nenhuma assinatura encontrada
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </TabPanel>

      {/* TAB: FATURAS */}
      <TabPanel value={tabValue} index={2}>
        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
          <Button startIcon={<Add />} variant="contained" onClick={() => setCreateOpen(true)}>
            Nova Cobrança
          </Button>
          <Button startIcon={<Refresh />} variant="outlined" onClick={loadBillings}>
            Atualizar
          </Button>
        </Box>

        <Grid container spacing={3}>
          {items.map((b) => (
            <Grid item xs={12} sm={6} md={4} key={b.billing_id}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
                      {b.billing_type}
                    </Typography>
                    <Chip
                      label={b.status}
                      color={getStatusColor(b.status) as any}
                      size="small"
                    />
                  </Box>
                  <Typography variant="h6" sx={{ mb: 1 }}>
                    {formatCurrency(b.amount)}
                  </Typography>
                  {b.due_date && (
                    <Typography variant="caption" color="text.secondary" display="block">
                      Vencimento: {new Date(b.due_date).toLocaleDateString('pt-BR')}
                    </Typography>
                  )}
                  {b.paid_at && (
                    <Typography variant="caption" color="text.secondary" display="block">
                      Pago em: {new Date(b.paid_at).toLocaleDateString('pt-BR')}
                    </Typography>
                  )}
                  <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                    {b.status !== 'paid' && (
                      <Button
                        size="small"
                        startIcon={<Check />}
                        onClick={() => markPaid(b.billing_id)}
                        variant="outlined"
                      >
                        Marcar pago
                      </Button>
                    )}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
          {items.length === 0 && (
            <Grid item xs={12}>
              <Typography variant="body2" color="text.secondary" align="center">
                Nenhuma fatura encontrada
              </Typography>
            </Grid>
          )}
        </Grid>
      </TabPanel>

      {/* DIALOG: NOVA COBRANÇA */}
      <Dialog open={createOpen} onClose={() => setCreateOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Nova Cobrança</DialogTitle>
        <DialogContent>
          <FormControl fullWidth margin="normal">
            <InputLabel>Tipo</InputLabel>
            <Select
              label="Tipo"
              value={newBill.billing_type}
              onChange={(e) => setNewBill({ ...newBill, billing_type: e.target.value })}
            >
              <MenuItem value="subscription">Assinatura</MenuItem>
              <MenuItem value="service">Serviço</MenuItem>
              <MenuItem value="license">Licença</MenuItem>
            </Select>
          </FormControl>
          <TextField
            fullWidth
            label="Valor (R$)"
            type="number"
            margin="normal"
            value={newBill.amount}
            onChange={(e) => {
              const value = e.target.value;
              setNewBill({ ...newBill, amount: value ? parseFloat(String(value)) : 0 });
            }}
          />
          <TextField
            fullWidth
            label="Vencimento"
            type="date"
            margin="normal"
            InputLabelProps={{ shrink: true }}
            onChange={(e) => setNewBill({ ...newBill, due_date: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCreateOpen(false)}>Cancelar</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!newBill.amount}>
            Criar
          </Button>
        </DialogActions>
      </Dialog>

      {/* DIALOG: ASSINAR PLANO */}
      <Dialog open={subscribeOpen} onClose={() => setSubscribeOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Assinar Plano</DialogTitle>
        <DialogContent>
          {selectedPlan && (
            <Box>
              <Typography variant="h6" gutterBottom>
                {selectedPlan.name}
              </Typography>
              <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
                {formatCurrency(selectedPlan.price, selectedPlan.currency)}
                <Typography component="span" variant="body2" color="text.secondary">
                  {' '}/ {selectedPlan.billing_interval === 'month' ? 'mês' : 'ano'}
                </Typography>
              </Typography>
              <Alert severity="info" sx={{ mt: 2 }}>
                Você será redirecionado para o Stripe Checkout para completar o pagamento.
              </Alert>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSubscribeOpen(false)}>Cancelar</Button>
          <Button variant="contained" onClick={handleSubscribe} disabled={!selectedPlan}>
            Continuar para Pagamento
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Billing;
